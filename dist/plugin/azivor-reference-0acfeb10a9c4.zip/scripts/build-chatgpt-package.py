"""Build a ChatGPT account plugin from a verified account-local App connection."""
from pathlib import Path
import argparse, json, re, zipfile

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app-id", required=True, help="Verified App ID from this user's ChatGPT connection")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--version", help="Optional higher semantic version for an existing plugin")
    args = parser.parse_args()
    if not re.fullmatch(r"(?:asdk_app_|connector_|templated_apps_)[A-Za-z0-9][A-Za-z0-9_-]*", args.app_id):
        parser.error("Use a verified App ID, not a plugin ID, URL or placeholder")
    source = Path(__file__).resolve().parents[1]
    manifest = json.loads((source / "plugin.json").read_text())
    if args.version:
        if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", args.version):
            parser.error("Version must use major.minor.patch")
        manifest["version"] = args.version
    settings = manifest["extensions"]["com.openai"]
    settings["apps"] = "./.app.json"
    app = {"apps": {"azivor-reference-api": {"id": args.app_id}}}
    compatibility = {key: manifest[key] for key in ["name", "version", "description", "author", "keywords", "homepage"] if key in manifest}
    compatibility.update({"interface": settings["interface"], "skills": "./skills", "apps": "./.app.json"})
    files = {"plugin.json": (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode(),
             ".app.json": (json.dumps(app, indent=2) + "\n").encode(),
             ".codex-plugin/plugin.json": (json.dumps(compatibility, indent=2, ensure_ascii=False) + "\n").encode()}
    for relative in ["skills/azivor-reference/SKILL.md", "assets/reference-icon.png"]:
        files[relative] = (source / relative).read_bytes()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if source == args.output.resolve() or source in args.output.resolve().parents:
        parser.error("Write the generated ZIP outside the extracted source directory")
    with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in files.items():
            archive.writestr(name, data)
    with zipfile.ZipFile(args.output) as archive:
        assert archive.testzip() is None
        assert "mcp.json" not in archive.namelist() and ".mcp.json" not in archive.namelist()
    print(json.dumps({"archive": str(args.output.resolve()), "app_id": args.app_id, "files": sorted(files)}))

if __name__ == "__main__":
    main()
