---
name: azivor-reference
description: Find and show visual design references from Azivor’s curated image library. Use for reference searches, brand artwork, and art-direction inspiration through Azivor Reference.
---

Use the connected Azivor Reference API search tool to retrieve real references. Keep the selection small, normally three images. For “try it,” “show references,” or another request without a style or brand, call search with limit 3 and omit query to show a starter selection. Do not stop at browse_collections when the user wants images. Use fetch for a specific id returned by search. Search and fetch return actual image content and an inline image component which renders directly inside the conversation.

Preserve the complete tool result and UI metadata, and prefer direct tool calls when showing images. The component uses the exact GitHub gallery assets and includes the title, Azivor’s independent design note, and original-source link. Add only brief analysis that helps explain the visual fit.

Only show images supplied by the API. Do not call web image search or substitute independently retrieved thumbnails, generated artwork, or similar-looking images. Do not create a separate interface or website. Do not claim that an image is visible solely because the tool succeeded. If this host exposes native image content through a code helper, forward each returned image block with its image display helper rather than printing or dropping the blocks. If no inline component or native image display is available, embed the exact returned preview URLs as Markdown images, with source links. Do not claim an image is visible solely because a tool succeeded; if display still fails, say so and provide the exact returned preview and source links.

Never invent references, image URLs, brand intent, or reuse rights. Explain partial matches and empty results honestly. The gallery is https://azivor.github.io/reference/.
